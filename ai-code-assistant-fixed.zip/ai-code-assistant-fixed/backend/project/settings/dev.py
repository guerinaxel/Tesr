from .base import *  # noqa

DEBUG = True
ALLOWED_HOSTS = ["*"]
